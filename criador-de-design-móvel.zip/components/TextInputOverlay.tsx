import React, { useState, useEffect, useRef } from 'react';
import { CloseIcon, CheckIcon } from './icons';

interface TextInputOverlayProps {
  isOpen: boolean;
  initialValue: string;
  onConfirm: (text: string) => void;
  onCancel: () => void;
}

export const TextInputOverlay: React.FC<TextInputOverlayProps> = ({
  isOpen,
  initialValue,
  onConfirm,
  onCancel,
}) => {
  const [currentText, setCurrentText] = useState(initialValue);
  const [error, setError] = useState<string | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (isOpen) {
      setCurrentText(initialValue);
      setError(null);
      // Focar e selecionar o texto ao abrir
      setTimeout(() => { // Timeout para garantir que o elemento esteja visível e focar
        if (textareaRef.current) {
          textareaRef.current.focus();
          textareaRef.current.select();
        }
      }, 50);
    }
  }, [isOpen, initialValue]);

  const handleConfirmClick = () => {
    if (currentText.trim() === '') {
      setError('O texto não pode estar vazio.');
      if (textareaRef.current) {
        textareaRef.current.focus();
      }
      return;
    }
    setError(null);
    onConfirm(currentText);
  };

  const handleTextChange = (event: React.ChangeEvent<HTMLTextAreaElement>) => {
    setCurrentText(event.target.value);
    if (error && event.target.value.trim() !== '') {
      setError(null); // Limpar erro ao começar a digitar algo válido
    }
  };
  
  // Permitir confirmação com Enter (Shift+Enter para nova linha)
  const handleKeyDown = (event: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault(); // Impedir nova linha
      handleConfirmClick();
    }
    if (event.key === 'Escape') {
      onCancel();
    }
  };


  if (!isOpen) {
    return null;
  }

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-gray-900/80 backdrop-blur-sm p-4"
      role="dialog"
      aria-modal="true"
    >
      <div className="relative w-full max-w-2xl bg-gray-800 shadow-2xl rounded-lg flex flex-col overflow-hidden">
        {/* Barra Superior com Botões */}
        <div className="flex items-center justify-between p-3 bg-gray-700/50 border-b border-gray-700">
          <button
            onClick={onCancel}
            title="Cancelar"
            aria-label="Cancelar edição de texto"
            className="p-2 rounded-full text-gray-400 hover:bg-gray-600 hover:text-red-400 transition-colors"
          >
            <CloseIcon className="w-6 h-6" />
          </button>
          <span className="text-lg font-semibold text-indigo-300">Editar Texto</span>
          <button
            onClick={handleConfirmClick}
            title="Confirmar Texto"
            aria-label="Confirmar texto"
            className="p-2 rounded-full text-gray-400 hover:bg-gray-600 hover:text-green-400 transition-colors"
          >
            <CheckIcon className="w-6 h-6" />
          </button>
        </div>

        {/* Área de Texto Editável */}
        <div className="p-6 flex-grow">
          <textarea
            ref={textareaRef}
            value={currentText}
            onChange={handleTextChange}
            onKeyDown={handleKeyDown}
            className="w-full h-48 sm:h-64 p-4 bg-gray-900 text-gray-100 text-2xl sm:text-3xl md:text-4xl text-center resize-none border-2 border-transparent focus:border-indigo-500 rounded-md focus:outline-none focus:ring-0 placeholder-gray-500"
            placeholder="Digite seu texto aqui..."
            spellCheck="false"
            autoCapitalize="sentences"
          />
        </div>
         {error && (
            <div className="p-3 text-center bg-red-800/50 text-red-300 text-sm border-t border-gray-700">
                {error}
            </div>
        )}
      </div>
    </div>
  );
};
