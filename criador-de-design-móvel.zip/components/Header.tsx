
import React from 'react';
import { LayersIcon, HomeIcon, PanelRightIcon } from './icons'; // Adicionado PanelRightIcon

interface HeaderProps {
  title: string;
  projectName?: string;
  onGoHome?: () => void;
  isLayersPanelOpen?: boolean; // Para feedback visual no botão, se necessário
  onToggleLayersPanel?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ title, projectName, onGoHome, isLayersPanelOpen, onToggleLayersPanel }) => {
  return (
    <header className="bg-gray-800 shadow-md p-3 flex items-center justify-between">
      <div className="flex items-center">
        {onGoHome && (
          <button
            onClick={onGoHome}
            title="Voltar à Tela Inicial"
            aria-label="Voltar à Tela Inicial"
            className="p-2 rounded-full hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-indigo-400 mr-3 transition-colors"
          >
            <HomeIcon className="w-6 h-6 text-gray-300 hover:text-indigo-400" />
          </button>
        )}
        <LayersIcon className="w-7 h-7 mr-2 text-indigo-400" />
        <h1 className="text-xl font-semibold text-gray-100 truncate">
          {title} 
          {projectName && <span className="font-normal text-indigo-300"> | {projectName}</span>}
        </h1>
      </div>
      
      <div className="flex items-center space-x-2">
        {/* Placeholder for future actions like Save, Export, etc. */}
        {/* <button className="px-3 py-1.5 text-sm bg-indigo-600 hover:bg-indigo-500 rounded-md text-white transition-colors">
          Salvar
        </button> */}

        {onToggleLayersPanel && (
          <button
            onClick={onToggleLayersPanel}
            title={isLayersPanelOpen ? "Fechar Painel de Camadas" : "Abrir Painel de Camadas"}
            aria-label={isLayersPanelOpen ? "Fechar Painel de Camadas" : "Abrir Painel de Camadas"}
            className={`p-2 rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-400 ${
                isLayersPanelOpen ? 'bg-indigo-600 hover:bg-indigo-500' : 'hover:bg-gray-700'
            }`}
          >
            <PanelRightIcon className={`w-6 h-6 ${isLayersPanelOpen ? 'text-white' : 'text-gray-300 hover:text-indigo-400'}`} />
          </button>
        )}
      </div>
    </header>
  );
};