
import React, { ChangeEvent, useCallback } from 'react';
import { DesignElement, TextElement, RectangleElement, ImageElement, CircleElement, ToolOption } from '../types';
import { TrashIcon } from './icons'; // Assuming you might add a delete button

interface PropertiesPanelProps {
  selectedElement: DesignElement | null;
  updateElement: (id: string, updates: Partial<DesignElement>) => void;
  // TODO: Add deleteElement: (id: string) => void;
}

const commonFields: (keyof DesignElement)[] = ['x', 'y', 'width', 'height', 'rotation'];

export const PropertiesPanel: React.FC<PropertiesPanelProps> = ({ selectedElement, updateElement }) => {
  const handleInputChange = useCallback((event: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    if (!selectedElement) return;
    const { name, value } = event.target;
    let numericValue: string | number = ['x', 'y', 'width', 'height', 'fontSize', 'rotation', 'strokeWidth', 'cornerRadius'].includes(name) ? parseFloat(value) : value;
    
    if (name === 'rotation' && typeof numericValue === 'number') {
        if (numericValue > 360) numericValue = 360;
        if (numericValue < -360) numericValue = -360; // Though rotation usually is 0-360
    }
     if (name === 'strokeWidth' && typeof numericValue === 'number') {
        if (numericValue < 0) numericValue = 0;
    }
     if (name === 'cornerRadius' && typeof numericValue === 'number') {
        if (numericValue < 0) numericValue = 0;
    }


    updateElement(selectedElement.id, { [name]: numericValue });
  }, [selectedElement, updateElement]);

  const renderCommonFields = () => {
    if (!selectedElement) return null;
    return (
      <>
        {commonFields.map(field => (
          <div key={field} className="mb-3">
            <label htmlFor={field} className="block text-xs font-medium text-gray-400 mb-1 capitalize">{field}</label>
            <input
              type={field === 'rotation' ? 'number' : 'number'}
              id={field}
              name={field}
              value={(selectedElement[field as keyof DesignElement] as number) || 0}
              onChange={handleInputChange}
              className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-sm focus:ring-indigo-500 focus:border-indigo-500"
              step={field === 'rotation' ? 1 : 1}
            />
          </div>
        ))}
      </>
    );
  };
  
  const renderSpecificFields = () => {
    if (!selectedElement) return null;

    switch (selectedElement.type) {
      case ToolOption.TEXT:
        const textEl = selectedElement as TextElement;
        return (
          <>
            <div className="mb-3">
              <label htmlFor="text" className="block text-xs font-medium text-gray-400 mb-1">Conteúdo</label>
              <textarea
                id="text"
                name="text"
                value={textEl.text}
                onChange={handleInputChange}
                className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-sm focus:ring-indigo-500 focus:border-indigo-500 h-20 resize-none"
              />
            </div>
            <div className="mb-3">
              <label htmlFor="fontSize" className="block text-xs font-medium text-gray-400 mb-1">Tam. Fonte</label>
              <input type="number" id="fontSize" name="fontSize" value={textEl.fontSize} onChange={handleInputChange} className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-sm" />
            </div>
            <div className="mb-3">
              <label htmlFor="fontFamily" className="block text-xs font-medium text-gray-400 mb-1">Fonte</label>
              <input type="text" id="fontFamily" name="fontFamily" value={textEl.fontFamily} onChange={handleInputChange} className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-sm" />
            </div>
            <div className="mb-3">
              <label htmlFor="color" className="block text-xs font-medium text-gray-400 mb-1">Cor</label>
              <input type="color" id="color" name="color" value={textEl.color} onChange={handleInputChange} className="w-full h-10 p-1 bg-gray-700 border border-gray-600 rounded-md" />
            </div>
             <div className="mb-3">
                <label htmlFor="fontWeight" className="block text-xs font-medium text-gray-400 mb-1">Peso da Fonte</label>
                <select id="fontWeight" name="fontWeight" value={textEl.fontWeight || 'normal'} onChange={handleInputChange} className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-sm">
                    <option value="normal">Normal</option>
                    <option value="bold">Negrito</option>
                </select>
            </div>
            <div className="mb-3">
                <label htmlFor="textAlign" className="block text-xs font-medium text-gray-400 mb-1">Alinhamento Texto</label>
                <select id="textAlign" name="textAlign" value={textEl.textAlign || 'left'} onChange={handleInputChange} className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-sm">
                    <option value="left">Esquerda</option>
                    <option value="center">Centro</option>
                    <option value="right">Direita</option>
                </select>
            </div>
          </>
        );
      case ToolOption.RECTANGLE:
      case ToolOption.CIRCLE:
        const shapeEl = selectedElement as RectangleElement | CircleElement;
        return (
          <>
            <div className="mb-3">
              <label htmlFor="backgroundColor" className="block text-xs font-medium text-gray-400 mb-1">Cor de Fundo</label>
              <input type="color" id="backgroundColor" name="backgroundColor" value={shapeEl.backgroundColor} onChange={handleInputChange} className="w-full h-10 p-1 bg-gray-700 border border-gray-600 rounded-md" />
            </div>
            <div className="mb-3">
                <label htmlFor="strokeColor" className="block text-xs font-medium text-gray-400 mb-1">Cor da Borda</label>
                <input type="color" id="strokeColor" name="strokeColor" value={shapeEl.strokeColor || '#000000'} onChange={handleInputChange} className="w-full h-10 p-1 bg-gray-700 border border-gray-600 rounded-md" />
            </div>
            <div className="mb-3">
                <label htmlFor="strokeWidth" className="block text-xs font-medium text-gray-400 mb-1">Largura da Borda</label>
                <input type="number" id="strokeWidth" name="strokeWidth" value={shapeEl.strokeWidth || 0} min="0" onChange={handleInputChange} className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-sm" />
            </div>
            {selectedElement.type === ToolOption.RECTANGLE && (
                 <div className="mb-3">
                    <label htmlFor="cornerRadius" className="block text-xs font-medium text-gray-400 mb-1">Raio do Canto</label>
                    <input type="number" id="cornerRadius" name="cornerRadius" value={(selectedElement as RectangleElement).cornerRadius || 0} min="0" onChange={handleInputChange} className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-sm" />
                </div>
            )}
          </>
        );
      case ToolOption.IMAGE:
        const imgEl = selectedElement as ImageElement;
        return (
          <>
            <div className="mb-3">
              <label htmlFor="src" className="block text-xs font-medium text-gray-400 mb-1">URL da Imagem</label>
              <input type="text" id="src" name="src" value={imgEl.src} onChange={handleInputChange} className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-sm" />
            </div>
            <div className="mb-3">
              <label htmlFor="alt" className="block text-xs font-medium text-gray-400 mb-1">Texto Alternativo</label>
              <input type="text" id="alt" name="alt" value={imgEl.alt || ''} onChange={handleInputChange} className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-sm" />
            </div>
          </>
        );
      default:
        return null;
    }
  };

  if (!selectedElement) {
    return (
      <aside className="w-72 bg-gray-800 border-l border-gray-700 p-4 shadow-lg">
        <h3 className="text-lg font-semibold text-gray-200 mb-4">Propriedades</h3>
        <p className="text-sm text-gray-500">Selecione um elemento para editar suas propriedades.</p>
      </aside>
    );
  }

  return (
    <aside className="w-72 bg-gray-800 border-l border-gray-700 p-4 overflow-y-auto shadow-lg">
      <h3 className="text-lg font-semibold text-gray-200 mb-4">Propriedades do Elemento</h3>
      <div className="mb-2 text-xs text-gray-500">ID: {selectedElement.id}</div>
      <div className="mb-2 text-xs text-gray-500">Tipo: {selectedElement.type}</div>
      
      <div className="space-y-4">
        {renderCommonFields()}
        {renderSpecificFields()}
      </div>

      {/* Placeholder for delete button */}
      {/* <button 
        onClick={() => {
          // deleteElement(selectedElement.id) 
        }}
        className="mt-6 w-full flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
      >
        <TrashIcon className="w-4 h-4 mr-2" />
        Deletar Elemento
      </button> */}
    </aside>
  );
};
