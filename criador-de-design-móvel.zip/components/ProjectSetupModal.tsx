
import React, { useState, FormEvent, ChangeEvent, useEffect } from 'react';

interface ProjectSetupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (config: { name: string; width: number; height: number }) => void;
  defaultProjectName: string;
  defaultCanvasWidth: number;
  defaultCanvasHeight: number;
}

const MIN_DIMENSION = 100;
const MAX_DIMENSION = 4000;

export const ProjectSetupModal: React.FC<ProjectSetupModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  defaultProjectName,
  defaultCanvasWidth,
  defaultCanvasHeight
}) => {
  const [name, setName] = useState(defaultProjectName || "Novo Projeto");
  const [width, setWidth] = useState<string>(String(defaultCanvasWidth));
  const [height, setHeight] = useState<string>(String(defaultCanvasHeight));
  const [validationError, setValidationError] = useState<string | null>(null);

  // Efeito para resetar os campos quando as props default mudarem (ex: ao reabrir a modal)
  useEffect(() => {
    if (isOpen) {
        setName(defaultProjectName || "Novo Projeto");
        setWidth(String(defaultCanvasWidth));
        setHeight(String(defaultCanvasHeight));
        setValidationError(null); // Limpa erros anteriores
    }
  }, [isOpen, defaultProjectName, defaultCanvasWidth, defaultCanvasHeight]);


  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setValidationError(null); // Limpa erro anterior

    if (name.trim() === "") {
        setValidationError("O nome do projeto não pode estar vazio.");
        return;
    }

    if (width.trim() === "") {
        setValidationError("A largura do canvas não pode estar vazia.");
        return;
    }
    if (height.trim() === "") {
        setValidationError("A altura do canvas não pode estar vazia.");
        return;
    }

    const parsedWidth = parseInt(width, 10);
    const parsedHeight = parseInt(height, 10);

    if (isNaN(parsedWidth) || isNaN(parsedHeight)) {
      setValidationError("Por favor, insira valores numéricos válidos para largura e altura.");
      return;
    }

    if (parsedWidth < MIN_DIMENSION || parsedHeight < MIN_DIMENSION) {
        setValidationError(`As dimensões mínimas do canvas são ${MIN_DIMENSION}x${MIN_DIMENSION} pixels.`);
        return;
    }

    if (parsedWidth > MAX_DIMENSION || parsedHeight > MAX_DIMENSION) {
        setValidationError(`As dimensões máximas do canvas são ${MAX_DIMENSION}x${MAX_DIMENSION} pixels.`);
        return;
    }

    onSubmit({ name, width: parsedWidth, height: parsedHeight });
  };

  if (!isOpen) {
    return null;
  }

  return (
    <div 
        className="fixed inset-0 bg-gray-900 bg-opacity-75 flex items-center justify-center z-50 p-4"
        onClick={onClose} 
        role="dialog"
        aria-modal="true"
        aria-labelledby="project-setup-title"
    >
      <div 
        className="bg-gray-800 p-6 sm:p-8 rounded-lg shadow-2xl w-full max-w-md text-gray-100 transform transition-all"
        onClick={(e) => e.stopPropagation()} 
      >
        <div className="flex justify-between items-center mb-6">
            <h2 id="project-setup-title" className="text-2xl font-semibold text-indigo-400">Configurar Novo Projeto</h2>
            <button 
                onClick={onClose} 
                className="text-gray-400 hover:text-gray-200 transition-colors text-2xl"
                aria-label="Fechar modal"
            >
                &times;
            </button>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="projectName" className="block text-sm font-medium text-gray-300 mb-1">
              Nome do Projeto
            </label>
            <input
              type="text"
              id="projectName"
              value={name}
              onChange={(e: ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
              className="w-full p-3 bg-gray-700 border border-gray-600 rounded-md text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            />
          </div>
          <div className="flex space-x-4">
            <div className="flex-1">
              <label htmlFor="canvasWidth" className="block text-sm font-medium text-gray-300 mb-1">
                Largura (px)
              </label>
              <input
                type="number" 
                id="canvasWidth"
                value={width}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setWidth(e.target.value)}
                className="w-full p-3 bg-gray-700 border border-gray-600 rounded-md text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                placeholder={`${MIN_DIMENSION}-${MAX_DIMENSION}`}
              />
            </div>
            <div className="flex-1">
              <label htmlFor="canvasHeight" className="block text-sm font-medium text-gray-300 mb-1">
                Altura (px)
              </label>
              <input
                type="number" 
                id="canvasHeight"
                value={height}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setHeight(e.target.value)}
                className="w-full p-3 bg-gray-700 border border-gray-600 rounded-md text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                placeholder={`${MIN_DIMENSION}-${MAX_DIMENSION}`}
              />
            </div>
          </div>

          {validationError && (
            <div className="p-3 bg-red-700/30 border border-red-600 rounded-md text-red-300 text-sm">
              {validationError}
            </div>
          )}

          <div className="flex justify-end space-x-4 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2.5 text-sm font-medium text-gray-300 bg-gray-600 hover:bg-gray-500 rounded-md transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-gray-500"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-500 rounded-md transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-indigo-500"
            >
              Criar Projeto
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
