import React from 'react';

interface ToolbarButtonProps {
  label: string;
  onClick: () => void;
  children: React.ReactNode;
  // A propriedade isActive foi removida
}

export const ToolbarButton: React.FC<ToolbarButtonProps> = ({ label, onClick, children }) => {
  const buttonClasses = "p-2 rounded-lg flex flex-col items-center justify-center transition-all duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-indigo-400 min-w-[70px] bg-gray-700 hover:bg-gray-600 text-gray-300 hover:text-white";

  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={onClick}
      className={buttonClasses} // Usa sempre as classes base/inativas
    >
      {children}
      <span className="text-xs mt-1 whitespace-nowrap">{label}</span>
    </button>
  );
};
