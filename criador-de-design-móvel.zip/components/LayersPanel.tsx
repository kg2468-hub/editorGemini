
import React, { useState } from 'react'; 
import { DesignElement, ToolOption, TextElement } from '../types'; 
import { 
    CloseIcon, SquareIcon, TypeIcon, CircleIcon, ImageIcon, // Generic icons for fallback or specific uses
    EyeOpenIcon, EyeClosedIcon, LockOpenIcon, LockClosedIcon, DragHandleIcon 
} from './icons'; 
import { LayerItemPreview } from './LayerItemPreview'; // Import the new preview component

interface LayersPanelProps {
  isOpen: boolean;
  onClose: () => void;
  elements: DesignElement[];
  selectedElementId: string | null;
  onSelectElement: (id: string | null) => void;
  onToggleVisibility: (id: string) => void;
  onToggleLock: (id: string) => void;
  onReorderElements: (draggedId: string, targetId: string | null, position: 'before' | 'after') => void;
}

// This function can be kept for other uses or if a fallback icon is needed
const getElementIcon = (elementType: DesignElement['type']) => {
    switch (elementType) {
        case ToolOption.RECTANGLE: return SquareIcon;
        case ToolOption.CIRCLE: return CircleIcon;
        case ToolOption.TEXT: return TypeIcon;
        case ToolOption.IMAGE: return ImageIcon;
        default: 
            return SquareIcon; 
    }
}

export const LayersPanel: React.FC<LayersPanelProps> = ({ 
    isOpen, 
    onClose, 
    elements, 
    selectedElementId,
    onSelectElement,
    onToggleVisibility,
    onToggleLock,
    onReorderElements
}) => {
  const [draggedItemId, setDraggedItemId] = useState<string | null>(null);
  const [dropTargetInfo, setDropTargetInfo] = useState<{ id: string | null, position: 'before' | 'after' } | null>(null);


  if (!isOpen) {
    return null;
  }

  // Elements are displayed in reverse order of the main 'elements' array (newest/topmost first)
  const displayElements = [...elements].reverse();

  const handleDragStart = (e: React.DragEvent<HTMLLIElement>, elementId: string) => {
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', elementId); 
    setDraggedItemId(elementId);
    e.currentTarget.style.opacity = '0.5';
  };

  const handleDragOver = (e: React.DragEvent<HTMLElement>, targetElementId: string | null) => {
    e.preventDefault();
    if (!draggedItemId || (targetElementId && draggedItemId === targetElementId)) {
        setDropTargetInfo(null);
        return;
    }

    if (targetElementId === null) { 
        const panelRect = e.currentTarget.getBoundingClientRect(); 
        if (panelRect && e.clientY < panelRect.top + panelRect.height / 2 ) { 
            setDropTargetInfo({ id: displayElements.length > 0 ? displayElements[0].id : null, position: 'before' });
        } else { 
            setDropTargetInfo({ id: displayElements.length > 0 ? displayElements[displayElements.length -1].id : null, position: 'after' });
        }
        return;
    }
    
    const targetLi = e.currentTarget as HTMLLIElement; 
    const rect = targetLi.getBoundingClientRect();
    const midY = rect.top + rect.height / 2;
    const position = e.clientY < midY ? 'before' : 'after';
    setDropTargetInfo({ id: targetElementId, position });
  };
  
  const handleDragLeave = (e: React.DragEvent<HTMLElement>) => {
    if (!e.currentTarget.contains(e.relatedTarget as Node)) {
        setDropTargetInfo(null);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLElement>, targetElementIdOnLi: string | null) => {
    e.preventDefault();
    if (!draggedItemId || !dropTargetInfo) {
        setDropTargetInfo(null);
        setDraggedItemId(null);
        return;
    }
    
    const effectiveTargetId = dropTargetInfo.id; 
                                                
    if (draggedItemId !== effectiveTargetId || (draggedItemId === effectiveTargetId && dropTargetInfo.position)) { 
        onReorderElements(draggedItemId, effectiveTargetId, dropTargetInfo.position);
    }
    
    const allLiElements = (e.currentTarget.closest('ul') || e.currentTarget.querySelector('ul'))?.querySelectorAll('li');
    allLiElements?.forEach(li => {
        // Correctly find the dragged item if it was moved in the DOM by React re-render before dragEnd
        const liDraggableId = li.getAttribute('data-rbd-draggable-id');
        if (liDraggableId === draggedItemId) {
            li.style.opacity = '1';
        }
    });

    setDropTargetInfo(null);
    setDraggedItemId(null);
  };
  
  const handleDragEnd = (e: React.DragEvent<HTMLLIElement>) => {
    e.currentTarget.style.opacity = '1';
    setDropTargetInfo(null);
    setDraggedItemId(null);
  };


  return (
    <aside 
        className="w-72 bg-gray-800 border-l border-gray-700 p-0 flex flex-col shadow-lg transition-transform duration-300 ease-in-out"
        style={{ transform: isOpen ? 'translateX(0)' : 'translateX(100%)' }}
        onDragOver={(e) => handleDragOver(e, null)} 
        onDrop={(e) => handleDrop(e, null)}
        onDragLeave={handleDragLeave}
    >
      <div className="flex items-center justify-between p-3 border-b border-gray-700">
        <h3 className="text-lg font-semibold text-gray-200">Camadas</h3>
        <button
          onClick={onClose}
          title="Fechar Painel de Camadas"
          aria-label="Fechar Painel de Camadas"
          className="p-1 rounded-full hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-indigo-400"
        >
          <CloseIcon className="w-5 h-5 text-gray-400 hover:text-indigo-400" />
        </button>
      </div>

      {elements.length === 0 ? (
        <div className="p-4 text-sm text-gray-500 text-center flex-1 flex items-center justify-center">
          Nenhuma camada ainda. Adicione elementos ao canvas!
        </div>
      ) : (
        <ul className="overflow-y-auto flex-1 p-2 space-y-1" >
          {displayElements.map((element) => {
            const isSelected = element.id === selectedElementId;
            // const ElementIcon = getElementIcon(element.type); // Keep for potential fallback
            
            let displayName: string;
            if (element.type === ToolOption.TEXT) {
                const textContent = (element as TextElement).text;
                displayName = textContent.substring(0, 20) + (textContent.length > 20 ? '...' : '');
            } else {
                displayName = element.type.charAt(0).toUpperCase() + element.type.slice(1).toLowerCase();
            }
            
            const isVisible = element.isVisible ?? true;
            const isLocked = element.isLocked ?? false;

            return (
              <li
                key={element.id}
                draggable={!isLocked} 
                onDragStart={(e) => !isLocked && handleDragStart(e, element.id)}
                onDragOver={(e) => !isLocked && handleDragOver(e, element.id)}
                onDragLeave={handleDragLeave}
                onDrop={(e) => !isLocked && handleDrop(e, element.id)}
                onDragEnd={handleDragEnd}
                data-rbd-draggable-id={element.id} 
                className={`
                  relative group flex items-center p-2 rounded-md transition-colors space-x-1.5
                  ${isSelected && !isLocked ? 'bg-indigo-600 text-white' : 'hover:bg-gray-700 text-gray-300 hover:text-indigo-300'}
                  ${isLocked ? 'opacity-70 cursor-not-allowed' : (draggedItemId === element.id ? 'opacity-50' : 'cursor-pointer')}
                  ${!isVisible ? 'opacity-50' : ''}
                `}
                style={{
                    borderTop: dropTargetInfo?.id === element.id && dropTargetInfo?.position === 'before' ? '2px solid #4f46e5' : 'none',
                    borderBottom: dropTargetInfo?.id === element.id && dropTargetInfo?.position === 'after' ? '2px solid #4f46e5' : 'none',
                }}
              >
                {/* Preview */}
                <LayerItemPreview element={element} size={28} />

                {/* Visibility & Lock Buttons */}
                <div className="flex items-center space-x-1">
                    <button 
                        className="p-1 text-gray-400 hover:text-indigo-300 focus:outline-none"
                        title={isVisible ? "Ocultar camada" : "Mostrar camada"}
                        onClick={(e) => { e.stopPropagation(); onToggleVisibility(element.id); }}
                    >
                        {isVisible ? <EyeOpenIcon className="w-5 h-5" /> : <EyeClosedIcon className="w-5 h-5" />}
                    </button>
                    <button 
                        className="p-1 text-gray-400 hover:text-indigo-300 focus:outline-none"
                        title={isLocked ? "Desbloquear camada" : "Bloquear camada"}
                        onClick={(e) => { e.stopPropagation(); onToggleLock(element.id); }}
                    >
                        {isLocked ? <LockClosedIcon className="w-5 h-5" /> : <LockOpenIcon className="w-5 h-5" />}
                    </button>
                </div>

                {/* Layer Name/Info */}
                <div 
                    className="flex-1 truncate"
                    onClick={() => !isLocked && onSelectElement(element.id)} 
                    title={isLocked ? "Camada bloqueada" : `Selecionar ${displayName}`}
                >
                    <span className="text-sm truncate">
                    {displayName}
                    </span>
                </div>
                
                {/* Drag Handle */}
                <button 
                    className={`p-1 text-gray-500 hover:text-gray-300 focus:outline-none opacity-0 group-hover:opacity-100 transition-opacity ${isLocked ? 'cursor-not-allowed' : 'cursor-move'}`}
                    title={isLocked ? "Camada bloqueada" : "Reordenar camada"}
                    disabled={isLocked}
                    // This button is mainly a visual cue for draggability
                >
                    <DragHandleIcon className="w-5 h-5" />
                </button>
              </li>
            );
          })}
           {draggedItemId && dropTargetInfo && dropTargetInfo.id === null && dropTargetInfo.position === 'after' && (
              <li className="h-1 bg-indigo-500 rounded-full my-1 mx-2"></li>
            )}
            {draggedItemId && dropTargetInfo && dropTargetInfo.id === null && dropTargetInfo.position === 'before' && (
              <li className="h-1 bg-indigo-500 rounded-full my-1 mx-2"></li>
            )}
        </ul>
      )}
      <div className="p-3 border-t border-gray-700 text-xs text-gray-500">
        {elements.length} camada(s)
      </div>
    </aside>
  );
};
