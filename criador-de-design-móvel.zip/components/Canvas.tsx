
import React, { useRef, useState, MouseEvent as ReactMouseEvent, WheelEvent as ReactWheelEvent, useCallback, useEffect, TouchEvent as ReactTouchEvent } from 'react';
import { DesignElement, ToolOption, TextElement, RectangleElement, ImageElement, CircleElement } from '../types';

interface CanvasProps {
  elements: DesignElement[];
  selectedTool: ToolOption;
  addElement: (newElement: Omit<DesignElement, 'id'>) => void;
  setSelectedElementId: (id: string | null) => void;
  selectedElementId: string | null;
  updateElementPosition: (id:string, updates: Partial<DesignElement>) => void;
  canvasWidth: number;
  canvasHeight: number;
  onViewportReady?: (getViewportCenterFunction: () => { x: number; y: number }) => void;
  onEditTextElement: (elementId: string) => void;
}

const MIN_ZOOM = 0.05; 
const MAX_ZOOM = 5.0;
const ZOOM_SENSITIVITY = 0.001;
const INITIAL_PADDING = 40;
const MIN_ELEMENT_SIZE = 10;
const MIN_FONT_SIZE = 8;
const MIN_TEXT_BOX_WIDTH = 20;
const TRANSFORM_CONTROLS_COLOR = '#6366F1'; // Indigo-500
const FRAME_BACKGROUND_COLOR = 'rgb(75 85 99)'; // Tailwind gray-600


// Helper function to get element center
const getCenter = (element: DesignElement) => {
    return {
        x: element.x + element.width / 2,
        y: element.y + element.height / 2,
    };
};

// Helper function to rotate a point around a center
const rotatePoint = (point: {x: number, y: number}, center: {x: number, y: number}, angleRad: number) => {
    const s = Math.sin(angleRad);
    const c = Math.cos(angleRad);
    const px = point.x - center.x;
    const py = point.y - center.y;
    const xNew = px * c - py * s;
    const yNew = px * s + py * c;
    return {
        x: xNew + center.x,
        y: yNew + center.y,
    };
};

// Text Measurement Utility
const measureTextNodeDimensions = (
    text: string,
    fontSize: number,
    fontFamily: string,
    fontWeight: string | undefined,
    widthConstraint: number,
    lineHeightRatio: number = 1.4 
): { width: number; height: number } => {
    const measurer = document.createElement('div');
    document.body.appendChild(measurer);

    measurer.style.position = 'absolute';
    measurer.style.left = '-9999px';
    measurer.style.top = '-9999px';
    measurer.style.visibility = 'hidden';
    measurer.style.pointerEvents = 'none';
    measurer.style.boxSizing = 'border-box';

    const TempZoomForPadding = 1; 
    const horizontalPadding = Math.max(1, 2 / TempZoomForPadding) * 2; 
    const verticalPadding = Math.max(0.5, 1 / TempZoomForPadding) * 2; 
    
    measurer.style.width = `${Math.max(1, widthConstraint - horizontalPadding)}px`;
    measurer.style.fontSize = `${fontSize}px`;
    measurer.style.fontFamily = fontFamily;
    measurer.style.fontWeight = fontWeight || 'normal';
    measurer.style.whiteSpace = 'pre-wrap'; 
    measurer.style.wordBreak = 'break-word';  
    measurer.style.lineHeight = `${fontSize * lineHeightRatio}px`; 
    measurer.style.padding = `${verticalPadding / 2}px ${horizontalPadding / 2}px`;
    
    measurer.textContent = text;

    const measuredHeight = measurer.offsetHeight; 
    const finalWidth = widthConstraint; 

    document.body.removeChild(measurer);
    return { width: finalWidth, height: measuredHeight };
};


export const Canvas: React.FC<CanvasProps> = ({ 
    elements, 
    selectedTool, 
    // addElement, // No longer used directly by canvas click for ADD_SHAPE
    setSelectedElementId,
    selectedElementId,
    updateElementPosition,
    canvasWidth,
    canvasHeight,
    onViewportReady,
    onEditTextElement
}) => {
  const viewportRef = useRef<HTMLDivElement>(null);
  const canvasPaperRef = useRef<HTMLDivElement>(null);
  
  const [zoom, setZoom] = useState<number>(1);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isInitialTransformApplied, setIsInitialTransformApplied] = useState<boolean>(false);
  const [viewportSize, setViewportSize] = useState<{ width: number; height: number }>({ width: 0, height: 0 });
  
  const [isInteracting, setIsInteracting] = useState<boolean>(false);
  const [interactionType, setInteractionType] = useState<'pan' | 'dragElement' | 'transformElement' | null>(null);

  const [lastPointerPosition, setLastPointerPosition] = useState<{ x: number; y: number } | null>(null);
  
  const [draggingElement, setDraggingElement] = useState<{ id: string; offsetX: number; offsetY: number } | null>(null);
  const [lastClickTime, setLastClickTime] = useState(0);

  const [activeTransformHandle, setActiveTransformHandle] = useState<string | null>(null);
  const [transformInitialState, setTransformInitialState] = useState<{
    originalElement: DesignElement; 
    mouseCanvasX: number;
    mouseCanvasY: number;
    elementCenterX: number; 
    elementCenterY: number;
    fixedPointX?: number; 
    fixedPointY?: number;
    originalAngleToMouse?: number; 
  } | null>(null);


  const screenToCanvasCoordinates = useCallback((screenX: number, screenY: number) => {
    if (!viewportRef.current) return { x: 0, y: 0 };
    return {
      x: (screenX - pan.x) / zoom,
      y: (screenY - pan.y) / zoom,
    };
  }, [pan, zoom]);

  useEffect(() => {
    const viewportElement = viewportRef.current;
    if (!viewportElement) return;
    const resizeObserver = new ResizeObserver(entries => {
        for (let entry of entries) {
            setViewportSize({ width: entry.contentRect.width, height: entry.contentRect.height });
        }
    });
    resizeObserver.observe(viewportElement);
    if(viewportElement.clientWidth > 0 && viewportElement.clientHeight > 0) {
        setViewportSize({ width: viewportElement.clientWidth, height: viewportElement.clientHeight});
    }
    return () => resizeObserver.unobserve(viewportElement);
  }, []); 

  useEffect(() => {
    if (canvasWidth > 0 && canvasHeight > 0 && viewportSize.width > 0 && viewportSize.height > 0) {
      const viewportW = viewportSize.width;
      const viewportH = viewportSize.height;
      const availableWidth = Math.max(1, viewportW - INITIAL_PADDING * 2); 
      const availableHeight = Math.max(1, viewportH - INITIAL_PADDING * 2); 
      const zoomX = availableWidth / canvasWidth;
      const zoomY = availableHeight / canvasHeight;
      const newZoom = Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, zoomX, zoomY));
      const zoomedCanvasWidth = canvasWidth * newZoom;
      const zoomedCanvasHeight = canvasHeight * newZoom;
      const newPanX = (viewportW - zoomedCanvasWidth) / 2;
      const newPanY = (viewportH - zoomedCanvasHeight) / 2;
      setZoom(newZoom);
      setPan({ x: newPanX, y: newPanY });
      setIsInitialTransformApplied(true); 
    } else {
      setIsInitialTransformApplied(false); 
    }
  }, [canvasWidth, canvasHeight, viewportSize]); 

  useEffect(() => {
    if (onViewportReady && viewportRef.current && isInitialTransformApplied && viewportSize.width > 0 && viewportSize.height > 0) {
      const getViewportCenter = () => {
        if (!viewportRef.current) return { x: canvasWidth / 2, y: canvasHeight / 2 };
        const screenCenterX = viewportRef.current.clientWidth / 2;
        const screenCenterY = viewportRef.current.clientHeight / 2;
        return screenToCanvasCoordinates(screenCenterX, screenCenterY);
      };
      onViewportReady(getViewportCenter);
    }
  }, [pan, zoom, viewportSize, isInitialTransformApplied, canvasWidth, canvasHeight, onViewportReady, screenToCanvasCoordinates]);

  const handleWheelZoom = useCallback((event: ReactWheelEvent<HTMLDivElement>) => {
    event.preventDefault();
    if (!viewportRef.current) return;
    const rect = viewportRef.current.getBoundingClientRect();
    const mouseX = event.clientX - rect.left; 
    const mouseY = event.clientY - rect.top;
    const zoomFactor = 1 - event.deltaY * ZOOM_SENSITIVITY;
    let newZoomAttempt = zoom * zoomFactor;
    const newZoom = Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, newZoomAttempt));
    let newPanX = pan.x;
    let newPanY = pan.y;
    if (newZoom !== zoom) { 
        newPanX = mouseX - (mouseX - pan.x) * (newZoom / zoom);
        newPanY = mouseY - (mouseY - pan.y) * (newZoom / zoom);
    }
    setZoom(newZoom);
    setPan({ x: newPanX, y: newPanY });
  }, [zoom, pan]);
  
  
  const initiateTransformation = (
    clientX: number, clientY: number, element: DesignElement, handleType: string
  ) => {
    if (element.isLocked || !viewportRef.current) return;
    
    setSelectedElementId(element.id);
    setActiveTransformHandle(handleType);
    setInteractionType('transformElement');
    setIsInteracting(true);

    const rect = viewportRef.current.getBoundingClientRect();
    const screenMouseX = clientX - rect.left;
    const screenMouseY = clientY - rect.top;
    const { x: mouseCanvasX, y: mouseCanvasY } = screenToCanvasCoordinates(screenMouseX, screenMouseY);
    
    const elementCenter = getCenter(element);
    let originalAngleToMouse;

    if (handleType === 'rotate') {
        originalAngleToMouse = Math.atan2(mouseCanvasY - elementCenter.y, mouseCanvasX - elementCenter.x);
    }
    
    let fixedPointX = elementCenter.x;
    let fixedPointY = elementCenter.y;

    if (handleType.includes('n')) fixedPointY = element.y + element.height;
    if (handleType.includes('s')) fixedPointY = element.y;
    if (handleType.includes('w')) fixedPointX = element.x + element.width;
    if (handleType.includes('e')) fixedPointX = element.x;

    if (handleType === 'nw') { fixedPointX = element.x + element.width; fixedPointY = element.y + element.height; }
    if (handleType === 'ne') { fixedPointX = element.x; fixedPointY = element.y + element.height; }
    if (handleType === 'sw') { fixedPointX = element.x + element.width; fixedPointY = element.y; }
    if (handleType === 'se') { fixedPointX = element.x; fixedPointY = element.y; }

    setTransformInitialState({
      originalElement: JSON.parse(JSON.stringify(element)), 
      mouseCanvasX,
      mouseCanvasY,
      elementCenterX: elementCenter.x,
      elementCenterY: elementCenter.y,
      originalAngleToMouse,
      fixedPointX, 
      fixedPointY,
    });
  };

  const handleTransformHandleMouseDown = (
    event: ReactMouseEvent<HTMLDivElement>, element: DesignElement, handleType: string
  ) => {
    event.stopPropagation();
    initiateTransformation(event.clientX, event.clientY, element, handleType);
  };
  const handleTransformHandleTouchStart = (
    event: ReactTouchEvent<HTMLDivElement>, element: DesignElement, handleType: string
  ) => {
    event.stopPropagation();
    if (event.touches.length === 1) {
      initiateTransformation(event.touches[0].clientX, event.touches[0].clientY, element, handleType);
    }
  };


  const handlePointerDown = (event: ReactMouseEvent<HTMLDivElement> | ReactTouchEvent<HTMLDivElement>) => {
    if (!viewportRef.current) return;
    
    let clientX, clientY;
    if ('touches' in event) { 
        if (event.touches.length > 1) return; 
        clientX = event.touches[0].clientX;
        clientY = event.touches[0].clientY;
    } else { 
        clientX = event.clientX;
        clientY = event.clientY;
    }

    const targetElement = (event.target as HTMLElement).closest('[data-element-id]');
    const targetHandle = (event.target as HTMLElement).closest('.transform-handle'); 
    if (targetHandle) return; 
    
    if (targetElement && 'touches' in event) { 
        // For touch events on elements, let element interaction start handle it.
        // This check prevents pan from starting if a touch event starts on an element.
        return; 
    }

    setLastPointerPosition({ x: clientX, y: clientY });

    // Only pan if SELECT tool is active and click is not on an element
    if (selectedTool === ToolOption.SELECT && !targetElement ) {
      setIsInteracting(true);
      setInteractionType('pan');
      if (viewportRef.current) viewportRef.current.style.cursor = 'grabbing';
      setSelectedElementId(null); 
      return;
    }
    // Removed ADD_SHAPE logic from here, as it's now handled in App.tsx
  };


  const handleElementInteractionStart = (
    clientX: number, clientY: number, element: DesignElement, event: ReactMouseEvent<HTMLDivElement> | ReactTouchEvent<HTMLDivElement>
  ) => {
    if ('stopPropagation' in event) event.stopPropagation();
    
    if (activeTransformHandle || interactionType === 'transformElement') return; 
    if (element.isLocked || !(element.isVisible ?? true)) return;

    const currentTime = new Date().getTime();
    if (currentTime - lastClickTime < 300 && selectedElementId === element.id) { // Ensure double click is on the same selected element
        if (element.type === ToolOption.TEXT && !element.isLocked) {
            onEditTextElement(element.id); 
            setLastClickTime(0); 
            setIsInteracting(false); 
            setInteractionType(null);
            return; 
        }
    }
    setLastClickTime(currentTime);

    if (selectedTool !== ToolOption.SELECT || !viewportRef.current) {
        setSelectedElementId(element.id); 
        return;
    }

    setSelectedElementId(element.id);
    const rect = viewportRef.current.getBoundingClientRect();
    const screenMouseX = clientX - rect.left;
    const screenMouseY = clientY - rect.top;
    const { x: canvasMouseX, y: canvasMouseY } = screenToCanvasCoordinates(screenMouseX, screenMouseY);
    
    setDraggingElement({ id: element.id, offsetX: canvasMouseX - element.x, offsetY: canvasMouseY - element.y });
    setIsInteracting(true);
    setInteractionType('dragElement');
    setLastPointerPosition({ x: clientX, y: clientY });
  };
  
  useEffect(() => {
    const handleGlobalPointerMove = (clientX: number, clientY: number) => {
        if (!isInteracting || !viewportRef.current) return;

        const rect = viewportRef.current.getBoundingClientRect();
        const screenMouseX = clientX - rect.left;
        const screenMouseY = clientY - rect.top;
        const { x: currentMouseCanvasX, y: currentMouseCanvasY } = screenToCanvasCoordinates(screenMouseX, screenMouseY);

        if (interactionType === 'pan' && lastPointerPosition) {
            const dx = clientX - lastPointerPosition.x;
            const dy = clientY - lastPointerPosition.y;
            setPan(prevPan => ({ x: prevPan.x + dx, y: prevPan.y + dy }));
            setLastPointerPosition({ x: clientX, y: clientY });
        } else if (interactionType === 'dragElement' && draggingElement) {
            const el = elements.find(e => e.id === draggingElement.id);
            if (el && (el.isLocked || !(el.isVisible ?? true))) {
                setDraggingElement(null); setIsInteracting(false); setInteractionType(null);
                return;
            }
            let newX = currentMouseCanvasX - draggingElement.offsetX;
            let newY = currentMouseCanvasY - draggingElement.offsetY;
            
            // Allow elements to move freely, clipping handled by frame/viewport
            // newX = Math.max(0, newX); // Keep element's top-left from going negative on canvasPaper
            // newY = Math.max(0, newY); // Keep element's top-left from going negative on canvasPaper
            
            updateElementPosition(draggingElement.id, { x: newX, y: newY });
        } else if (interactionType === 'transformElement' && activeTransformHandle && transformInitialState) {
            const {
                originalElement, elementCenterX, elementCenterY, originalAngleToMouse,
                mouseCanvasX: initialMouseCanvasX, mouseCanvasY: initialMouseCanvasY,
            } = transformInitialState;

            const updates: Partial<DesignElement> = {};

            if (activeTransformHandle === 'rotate' && typeof originalAngleToMouse === 'number') {
                const currentAngleToMouse = Math.atan2(currentMouseCanvasY - elementCenterY, currentMouseCanvasX - elementCenterX);
                let newRotationDegrees = (currentAngleToMouse - originalAngleToMouse) * (180 / Math.PI) + (originalElement.rotation || 0);
                newRotationDegrees = ((newRotationDegrees % 360) + 360) % 360;
                updates.rotation = newRotationDegrees;
            } else { 
                if (originalElement.type === ToolOption.TEXT) {
                    const textEl = originalElement as TextElement;
                    let newFontSize = textEl.fontSize;
                    let newConstrainingWidth = textEl.width;
                    // let newX = textEl.x; 
                    // let newY = textEl.y;

                    const isCornerHandle = ['nw', 'ne', 'sw', 'se'].includes(activeTransformHandle);
                    const isSideWidthHandle = ['w', 'e'].includes(activeTransformHandle);

                    if (isCornerHandle) {
                        const distInitial = Math.sqrt(Math.pow(initialMouseCanvasX - elementCenterX, 2) + Math.pow(initialMouseCanvasY - elementCenterY, 2));
                        const distCurrent = Math.sqrt(Math.pow(currentMouseCanvasX - elementCenterX, 2) + Math.pow(currentMouseCanvasY - elementCenterY, 2));
                        let scaleFactor = (distInitial > 1) ? distCurrent / distInitial : 1;
                        scaleFactor = Math.max(0.01, scaleFactor);

                        newFontSize = Math.max(MIN_FONT_SIZE, textEl.fontSize * scaleFactor);
                        newConstrainingWidth = Math.max(MIN_TEXT_BOX_WIDTH, textEl.width * scaleFactor);
                        (updates as Partial<TextElement>).fontSize = newFontSize;
                    } else if (isSideWidthHandle) {
                        const currentRotationRad = (originalElement.rotation || 0) * (Math.PI / 180);
                        const dxMouseCanvas = currentMouseCanvasX - initialMouseCanvasX;
                        const dyMouseCanvas = currentMouseCanvasY - initialMouseCanvasY;
                        const cosA = Math.cos(-currentRotationRad);
                        const sinA = Math.sin(-currentRotationRad);
                        const localDx = dxMouseCanvas * cosA - dyMouseCanvas * sinA;

                        if (activeTransformHandle === 'e') {
                            newConstrainingWidth = Math.max(MIN_TEXT_BOX_WIDTH, textEl.width + localDx);
                        } else if (activeTransformHandle === 'w') {
                            newConstrainingWidth = Math.max(MIN_TEXT_BOX_WIDTH, textEl.width - localDx);
                        }
                    } else { 
                        updateElementPosition(originalElement.id, {});
                        return;
                    }

                    const { height: measuredHeight } = measureTextNodeDimensions(
                        textEl.text, newFontSize, textEl.fontFamily, textEl.fontWeight, newConstrainingWidth
                    );
                    const newHeight = Math.max(MIN_ELEMENT_SIZE, measuredHeight);

                    updates.width = newConstrainingWidth;
                    updates.height = newHeight;

                    if (isCornerHandle) {
                        updates.x = elementCenterX - newConstrainingWidth / 2;
                        updates.y = elementCenterY - newHeight / 2;
                    } else if (isSideWidthHandle) {
                        const currentRotationRad = (originalElement.rotation || 0) * (Math.PI / 180);
                        const cosR = Math.cos(currentRotationRad);
                        const sinR = Math.sin(currentRotationRad);
                        const deltaWidth = newConstrainingWidth - textEl.width;

                        if (activeTransformHandle === 'e') {
                            updates.x = originalElement.x; 
                            updates.y = originalElement.y; 
                        } else if (activeTransformHandle === 'w') {
                            updates.x = originalElement.x - deltaWidth * cosR;
                            updates.y = originalElement.y - deltaWidth * sinR;
                        }
                    }
                } else { // Generic element resize
                    const distInitial = Math.sqrt(Math.pow(initialMouseCanvasX - elementCenterX, 2) + Math.pow(initialMouseCanvasY - elementCenterY, 2));
                    const distCurrent = Math.sqrt(Math.pow(currentMouseCanvasX - elementCenterX, 2) + Math.pow(currentMouseCanvasY - elementCenterY, 2));
                    let scaleFactor = (distInitial > 1) ? distCurrent / distInitial : 1;
                    scaleFactor = Math.max(0.01, scaleFactor);
                    
                    updates.width = Math.max(MIN_ELEMENT_SIZE, originalElement.width * scaleFactor);
                    updates.height = Math.max(MIN_ELEMENT_SIZE, originalElement.height * scaleFactor);
                    updates.x = elementCenterX - (updates.width ?? originalElement.width) / 2;
                    updates.y = elementCenterY - (updates.height ?? originalElement.height) / 2;
                }
            }
            
            if (Object.keys(updates).length > 0) {
                updateElementPosition(originalElement.id, updates);
            }
        }
    };
    
    const handleGlobalPointerUp = () => {
        if (interactionType === 'pan' && viewportRef.current) {
            viewportRef.current.style.cursor = selectedTool === ToolOption.SELECT ? 'grab' : 'default'; // default when not SELECT
        }
        setIsInteracting(false);
        setInteractionType(null);
        setLastPointerPosition(null);
        setDraggingElement(null);
        setActiveTransformHandle(null);
        setTransformInitialState(null);
    };

    const handleMouseMove = (event: globalThis.MouseEvent) => handleGlobalPointerMove(event.clientX, event.clientY);
    const handleTouchMove = (event: globalThis.TouchEvent) => {
        if (event.touches.length === 1) {
            if (interactionType === 'pan' || interactionType === 'dragElement' || interactionType === 'transformElement') {
                 event.preventDefault(); 
            }
            handleGlobalPointerMove(event.touches[0].clientX, event.touches[0].clientY);
        }
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleGlobalPointerUp);
    document.addEventListener('touchmove', handleTouchMove, { passive: false }); 
    document.addEventListener('touchend', handleGlobalPointerUp);
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleGlobalPointerUp);
      document.removeEventListener('touchmove', handleTouchMove);
      document.removeEventListener('touchend', handleGlobalPointerUp);
    };
  }, [
    isInteracting, interactionType, lastPointerPosition, draggingElement, 
    screenToCanvasCoordinates, updateElementPosition, elements, 
    selectedTool, activeTransformHandle, transformInitialState, 
    pan, zoom 
  ]);

  const renderElement = (element: DesignElement) => {
    if (!(element.isVisible ?? true)) return null; 

    const isSelected = element.id === selectedElementId && !(element.isLocked ?? false);
    const selectionBorderWidth = Math.max(1, 2 / zoom); 
    
    // Default to 0 if strokeWidth is not present or undefined
    const elementStrokeWidth = (element as RectangleElement | CircleElement).strokeWidth ?? 0;
    const actualElementBorderWidth = Math.max(0.5, elementStrokeWidth / zoom);


    const baseStyle: React.CSSProperties = {
      position: 'absolute',
      left: element.x,
      top: element.y,
      width: element.width,
      height: element.height,
      transform: `rotate(${element.rotation || 0}deg)`,
      cursor: (element.isLocked ?? false) ? 'not-allowed' : (interactionType === 'dragElement' && draggingElement?.id === element.id ? 'grabbing':'grab'),
      boxSizing: 'border-box',
      userSelect: 'none',
      opacity: element.opacity ?? 1,
    };
    
    const renderTransformControls = () => {
        if (!isSelected) return null;

        const handleSize = Math.max(6, 8 / zoom); 
        const handleOffset = -handleSize / 2;
        const rotationHandleDistance = Math.max(15, 20 / zoom);
        const isTextSelected = element.type === ToolOption.TEXT;

        const handlesDef = [
            { type: 'nw', top: handleOffset, left: handleOffset, cursor: 'nwse-resize', disabled: false },
            { type: 'n', top: handleOffset, left: `calc(50% - ${handleSize/2}px)`, cursor: 'ns-resize', disabled: isTextSelected },
            { type: 'ne', top: handleOffset, right: handleOffset, cursor: 'nesw-resize', disabled: false  },
            { type: 'w', top: `calc(50% - ${handleSize/2}px)`, left: handleOffset, cursor: 'ew-resize', disabled: false  },
            { type: 'e', top: `calc(50% - ${handleSize/2}px)`, right: handleOffset, cursor: 'ew-resize', disabled: false  },
            { type: 'sw', bottom: handleOffset, left: handleOffset, cursor: 'nesw-resize', disabled: false  },
            { type: 's', bottom: handleOffset, left: `calc(50% - ${handleSize/2}px)`, cursor: 'ns-resize', disabled: isTextSelected },
            { type: 'se', bottom: handleOffset, right: handleOffset, cursor: 'nwse-resize', disabled: false  },
            { 
              type: 'rotate', 
              top: `calc(0% - ${handleSize/2}px - ${rotationHandleDistance}px)`, 
              left: `calc(50% - ${handleSize/2}px)`, 
              cursor: `url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 24 24' fill='none' stroke='${encodeURIComponent(TRANSFORM_CONTROLS_COLOR)}' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M23 4v6h-6'/%3E%3Cpath d='M20.49 15a9 9 0 1 1-2.12-9.36L23 10'/%3E%3C/svg%3E") 10 10, auto`,
              disabled: false 
            },
        ];

        return (
            <div 
                className="transform-controls-container" 
                style={{
                    position: 'absolute', left: 0, top: 0, width: '100%', height: '100%',
                    pointerEvents: 'none', 
                    border: `${selectionBorderWidth}px dashed ${TRANSFORM_CONTROLS_COLOR}`,
                    boxSizing: 'border-box',
                    zIndex: 100, 
                }}
            >
                {handlesDef.map(handle => (
                    <div
                        key={handle.type}
                        className={`transform-handle ${handle.type}-handle`} 
                        style={{
                            position: 'absolute',
                            width: handleSize, height: handleSize,
                            backgroundColor: handle.disabled ? '#888' : 'white',
                            border: `${Math.max(0.5, 1/zoom)}px solid ${handle.disabled ? '#666' : TRANSFORM_CONTROLS_COLOR}`,
                            borderRadius: handle.type === 'rotate' ? '50%' : '2px',
                            top: handle.top, left: handle.left,
                            right: handle.right, bottom: handle.bottom,
                            cursor: handle.disabled ? 'not-allowed' : handle.cursor,
                            pointerEvents: handle.disabled ? 'none' : 'auto', 
                            zIndex: 101, 
                        }}
                        onMouseDown={(e) => !handle.disabled && handleTransformHandleMouseDown(e, element, handle.type)}
                        onTouchStart={(e) => !handle.disabled && handleTransformHandleTouchStart(e, element, handle.type)}
                    />
                ))}
            </div>
        );
    };

    switch (element.type) {
      case ToolOption.TEXT:
        const textEl = element as TextElement;
        const textPaddingVertical = Math.max(0.5, 1 / zoom);
        const textPaddingHorizontal = Math.max(1, 2 / zoom);
        return (
          <div
            key={element.id} data-element-id={element.id}
            style={{ ...baseStyle }}
            onMouseDown={(e) => handleElementInteractionStart(e.clientX, e.clientY, element, e)}
            onTouchStart={(e) => handleElementInteractionStart(e.touches[0].clientX, e.touches[0].clientY, element, e)}
          >
            <div style={{
                color: textEl.color, 
                fontSize: textEl.fontSize, 
                fontFamily: textEl.fontFamily,
                fontWeight: textEl.fontWeight, textAlign: textEl.textAlign,
                width: '100%', height: '100%',
                display: 'flex', 
                alignItems: 'center', 
                justifyContent: textEl.textAlign === 'center' ? 'center' : textEl.textAlign === 'right' ? 'flex-end' : 'flex-start',
                paddingTop: textPaddingVertical, paddingBottom: textPaddingVertical,
                paddingLeft: textPaddingHorizontal, paddingRight: textPaddingHorizontal,
                overflow: 'hidden', whiteSpace: 'pre-wrap', wordBreak: 'break-word', 
                lineHeight: `${textEl.fontSize * 1.4}px`, 
                boxSizing: 'border-box',
            }}>
                {textEl.text}
            </div>
            {renderTransformControls()}
          </div>
        );
      case ToolOption.RECTANGLE:
        const rectEl = element as RectangleElement;
        return (
          <div
            key={element.id} data-element-id={element.id}
            style={{ 
                ...baseStyle, 
                backgroundColor: rectEl.backgroundColor,
                border: `${actualElementBorderWidth}px solid ${rectEl.strokeColor || 'transparent'}`,
                borderRadius: rectEl.cornerRadius ? `${rectEl.cornerRadius}px` : undefined,
            }}
             onMouseDown={(e) => handleElementInteractionStart(e.clientX, e.clientY, element, e)}
             onTouchStart={(e) => handleElementInteractionStart(e.touches[0].clientX, e.touches[0].clientY, element, e)}
          >
            {renderTransformControls()}
          </div>
        );
      case ToolOption.CIRCLE:
        const circleEl = element as CircleElement;
        return (
          <div
            key={element.id} data-element-id={element.id}
            style={{
              ...baseStyle, 
              backgroundColor: circleEl.backgroundColor, 
              borderRadius: '50%',
              border: `${actualElementBorderWidth}px solid ${circleEl.strokeColor || 'transparent'}`,
            }}
            onMouseDown={(e) => handleElementInteractionStart(e.clientX, e.clientY, element, e)}
            onTouchStart={(e) => handleElementInteractionStart(e.touches[0].clientX, e.touches[0].clientY, element, e)}
          >
            {renderTransformControls()}
          </div>
        );
      case ToolOption.IMAGE:
        return (
          <div 
            key={element.id} data-element-id={element.id} style={baseStyle} 
            onMouseDown={(e) => handleElementInteractionStart(e.clientX, e.clientY, element, e)}
            onTouchStart={(e) => handleElementInteractionStart(e.touches[0].clientX, e.touches[0].clientY, element, e)}
          >
            <img
                src={(element as ImageElement).src} alt={(element as ImageElement).alt || 'Imagem'}
                style={{ width: '100%', height: '100%', objectFit: 'cover', pointerEvents: 'none' }}
                draggable="false" 
            />
            {renderTransformControls()}
          </div>
        );
      default: return null;
    }
  };
  
  const viewportCursorStyle = (): string => {
    if (interactionType === 'transformElement') return 'default'; 
    if (interactionType === 'pan') return 'grabbing';
    if (selectedTool === ToolOption.SELECT && !interactionType) return 'grab'; 
    // For ADD tools, it used to be crosshair, but now ADD tools are immediate actions.
    // So, if not SELECT, it's likely no specific cursor, or 'default'.
    return 'default'; 
  }

  const gridLineThickness = Math.max(0.5, 1 / zoom); 
  const gridColor = "rgba(107, 114, 128, 0.3)"; 

  return (
    <div
      ref={viewportRef}
      className="w-full h-full bg-gray-600 overflow-hidden relative touch-none select-none" 
      style={{ cursor: viewportCursorStyle() }}
      onMouseDown={handlePointerDown} 
      onTouchStart={handlePointerDown} 
      onWheel={handleWheelZoom}
    >
      <div
        ref={canvasPaperRef}
        className="relative bg-white shadow-2xl origin-top-left"
        style={{
          width: canvasWidth,
          height: canvasHeight,
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
          visibility: isInitialTransformApplied ? 'visible' : 'hidden',
          overflow: 'visible', 
          zIndex: 10, 
        }}
      >
        <div className="absolute inset-0 pointer-events-none" style={{zIndex: 1}}> 
            {Array.from({ length: Math.floor(canvasHeight / (20 / Math.min(1, zoom))) +1 }).map((_, i) => ( 
                <div key={`h-${i}`} className="absolute w-full" style={{top: i * (20 / Math.min(1, zoom)), height: gridLineThickness, backgroundColor: gridColor }}></div>
            ))}
            {Array.from({ length: Math.floor(canvasWidth / (20 / Math.min(1, zoom))) +1 }).map((_, i) => ( 
                <div key={`w-${i}`} className="absolute h-full" style={{left: i * (20 / Math.min(1, zoom)), width: gridLineThickness, backgroundColor: gridColor}}></div>
            ))}
        </div>
        {elements.map(renderElement)}
      </div>

      {isInitialTransformApplied && viewportSize.width > 0 && viewportSize.height > 0 && (
        <>
          <div style={{
            position: 'absolute', top: 0, left: 0, right: 0,
            height: Math.max(0, pan.y),
            backgroundColor: FRAME_BACKGROUND_COLOR,
            zIndex: 20, pointerEvents: 'none',
          }} />
          <div style={{
            position: 'absolute', bottom: 0, left: 0, right: 0,
            height: Math.max(0, viewportSize.height - (pan.y + canvasHeight * zoom)),
            backgroundColor: FRAME_BACKGROUND_COLOR,
            zIndex: 20, pointerEvents: 'none',
          }} />
          <div style={{
            position: 'absolute', 
            top: Math.max(0, pan.y), 
            bottom: Math.max(0, viewportSize.height - (pan.y + canvasHeight * zoom)), 
            left: 0,
            width: Math.max(0, pan.x),
            backgroundColor: FRAME_BACKGROUND_COLOR,
            zIndex: 20, pointerEvents: 'none',
          }} />
          <div style={{
            position: 'absolute',
            top: Math.max(0, pan.y),
            bottom: Math.max(0, viewportSize.height - (pan.y + canvasHeight * zoom)),
            right: 0,
            width: Math.max(0, viewportSize.width - (pan.x + canvasWidth * zoom)),
            backgroundColor: FRAME_BACKGROUND_COLOR,
            zIndex: 20, pointerEvents: 'none',
          }} />
        </>
      )}
    </div>
  );
};
