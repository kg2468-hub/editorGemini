
import React from 'react';
import { ToolOption, DesignElement } from '../types';
import { ToolbarButton } from './ToolbarButton';
import { getToolbarForElement, ToolbarButtonConfig } from '../toolbarConfig'; // Import configurations

interface ToolbarProps {
  selectedTool: ToolOption; 
  onSelectTool: (tool: ToolOption) => void;
  selectedElement: DesignElement | null; // New prop for contextual toolbar
}

export const Toolbar: React.FC<ToolbarProps> = ({ selectedTool, onSelectTool, selectedElement }) => {
  const currentToolbarButtons = getToolbarForElement(selectedElement);

  return (
    <nav className="w-full bg-gray-800 border-t border-gray-700 p-2 flex flex-row items-center space-x-2 overflow-x-auto shadow-lg">
      {currentToolbarButtons.map(({ tool, label, icon: IconComponent }: ToolbarButtonConfig) => (
        <ToolbarButton
          key={tool}
          label={label}
          onClick={() => onSelectTool(tool)}
        >
          <IconComponent className="w-6 h-6" />
        </ToolbarButton>
      ))}
    </nav>
  );
};
