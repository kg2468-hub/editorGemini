
import React from 'react';
import { CloseIcon } from './icons';

interface OpacitySliderProps {
  isOpen: boolean;
  currentOpacity: number; // 0 to 1
  onOpacityChange: (newOpacity: number) => void;
  onClose: () => void;
}

export const OpacitySlider: React.FC<OpacitySliderProps> = ({
  isOpen,
  currentOpacity,
  onOpacityChange,
  onClose,
}) => {
  if (!isOpen) {
    return null;
  }

  const handleSliderChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onOpacityChange(parseFloat(event.target.value));
  };

  const percentage = Math.round(currentOpacity * 100);

  return (
    <div 
      className="fixed bottom-16 left-1/2 -translate-x-1/2 z-30 w-full max-w-xs sm:max-w-sm mb-2 pointer-events-auto"
      // bottom-16 ou similar para ficar acima da Toolbar. Ajuste conforme a altura da sua Toolbar.
      // A altura da Toolbar é p-2 (0.5rem * 2 = 1rem) + altura dos ícones/texto.
      // Se a Toolbar tem cerca de 4rem (64px), bottom-16 (4rem) + mb-2 (0.5rem) deve funcionar.
    >
      <div className="bg-gray-700 p-4 rounded-lg shadow-2xl border border-gray-600">
        <div className="flex items-center justify-between mb-3">
          <label htmlFor="opacity-slider" className="text-sm font-medium text-gray-200">
            Opacidade: <span className="font-semibold text-indigo-300">{percentage}%</span>
          </label>
          <button
            onClick={onClose}
            title="Fechar Opacidade"
            aria-label="Fechar controle de opacidade"
            className="p-1 rounded-full text-gray-400 hover:bg-gray-600 hover:text-indigo-300 transition-colors"
          >
            <CloseIcon className="w-5 h-5" />
          </button>
        </div>
        <input
          type="range"
          id="opacity-slider"
          min="0"
          max="1"
          step="0.01"
          value={currentOpacity}
          onChange={handleSliderChange}
          className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer" // Tailwind classes básicas, estilos mais detalhados em index.html
        />
      </div>
    </div>
  );
};
