
import React from 'react';
import { DesignElement, ToolOption, RectangleElement, CircleElement, ImageElement, TextElement } from '../types';
import { TypeIcon } from './icons'; // Using TypeIcon for text for now

interface LayerItemPreviewProps {
  element: DesignElement;
  size: number; // e.g., 28 (for 28x28px preview area)
}

const PREVIEW_BG_COLOR = 'bg-gray-600'; // Background for the preview viewport
const PREVIEW_BORDER_COLOR = 'border-gray-500';

export const LayerItemPreview: React.FC<LayerItemPreviewProps> = ({ element, size }) => {
  const commonWrapperStyle: React.CSSProperties = {
    width: size,
    height: size,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  };

  const renderContent = () => {
    // Calculate scale factor to fit the element within the preview size, maintaining aspect ratio
    let scaleFactor = Math.min(size / Math.max(1, element.width), size / Math.max(1, element.height));
    // Ensure scale factor is not excessively large if element is very small
    scaleFactor = Math.min(scaleFactor, 1.5); // Cap scaling up small elements

    const scaledWidth = element.width * scaleFactor;
    const scaledHeight = element.height * scaleFactor;

    const elementStyle: React.CSSProperties = {
      width: scaledWidth,
      height: scaledHeight,
      transform: `rotate(${element.rotation || 0}deg)`,
      transformOrigin: 'center center',
      boxSizing: 'border-box',
    };

    switch (element.type) {
      case ToolOption.RECTANGLE:
        const rectEl = element as RectangleElement;
        return (
          <div
            style={{
              ...elementStyle,
              backgroundColor: rectEl.backgroundColor,
              border: `${Math.max(0.5, (rectEl.strokeWidth || 0) * scaleFactor)}px solid ${rectEl.strokeColor || 'transparent'}`,
              borderRadius: rectEl.cornerRadius ? `${rectEl.cornerRadius * scaleFactor}px` : undefined,
            }}
          />
        );
      case ToolOption.CIRCLE:
        const circleEl = element as CircleElement;
        return (
          <div
            style={{
              ...elementStyle,
              backgroundColor: circleEl.backgroundColor,
              borderRadius: '50%',
              border: `${Math.max(0.5, (circleEl.strokeWidth || 0) * scaleFactor)}px solid ${circleEl.strokeColor || 'transparent'}`,
            }}
          />
        );
      case ToolOption.IMAGE:
        const imgEl = element as ImageElement;
        return (
          <img
            src={imgEl.src}
            alt={imgEl.alt || 'preview'}
            style={{
              width: '100%', // Use 100% of the preview box
              height: '100%',
              objectFit: 'contain', // Or 'cover'
              transform: `rotate(${element.rotation || 0}deg)`, // Rotation on image directly
            }}
            draggable="false"
          />
        );
      case ToolOption.TEXT:
        const textEl = element as TextElement;
        // Simplified text preview: an icon colored with the text's color
        // The TypeIcon uses "currentColor" for its stroke, so it inherits the color from this span.
        return (
          <span style={{ color: textEl.color, display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
            <TypeIcon className={`w-${Math.floor(size/5)} h-${Math.floor(size/5)}`} />
          </span>
        );
      default:
        return <div className="text-xs text-gray-400">?</div>;
    }
  };

  return (
    <div
      className={`rounded-sm border ${PREVIEW_BORDER_COLOR} ${PREVIEW_BG_COLOR} flex-shrink-0`}
      style={commonWrapperStyle}
      title={`Preview of ${element.type}`}
    >
      {renderContent()}
    </div>
  );
};
