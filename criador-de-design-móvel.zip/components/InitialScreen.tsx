import React, { useState, useEffect } from 'react';
import { LayersIcon, PlusIcon, ProjectsIcon, SettingsIcon, UserIcon } from './icons';

interface InitialScreenProps {
  onStartCreating: () => void;
}

const bannerImages = [
  'https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8d2ViJTIwZGVzaWdufGVufDB8fDB8fHww&auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1499951360447-b19be8fe80f5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8d2ViJTIwZGVzaWdufGVufDB8fDB8fHww&auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8dWklMjB1eHxlbnwwfHwwfHx8MA&auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1522199755839-a2bacb67c546?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTF8fHVpJTIwdXh8ZW58MHx8MHx8fDA&auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1509343256512-d77a5cb3791b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTV8fGFwcCUyMGRlc2lnbnxlbnwwfHwwfHx8MA&auto=format&fit=crop&w=1200&q=80'
];

interface NavButtonProps {
  text: string;
  Icon: React.FC<React.SVGProps<SVGSVGElement> & { className?: string }>;
  onClick?: () => void;
}

const NavButton: React.FC<NavButtonProps> = ({ text, Icon, onClick }) => (
  <button 
    onClick={onClick}
    className="flex flex-col items-center justify-center p-2 rounded-lg text-gray-300 hover:bg-gray-700/70 hover:text-indigo-300 transition-colors w-20 focus:outline-none focus:ring-2 focus:ring-indigo-400"
    aria-label={text}
    title={text}
  >
    <Icon className="w-5 h-5 mb-0.5" />
    <span className="text-xs">{text}</span>
  </button>
);


export const InitialScreen: React.FC<InitialScreenProps> = ({ onStartCreating }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => {
      setCurrentImageIndex((prevIndex) => (prevIndex + 1) % bannerImages.length);
    }, 5000); // Mudar imagem a cada 5 segundos
    return () => clearTimeout(timer);
  }, [currentImageIndex]);

  return (
    <div className="relative flex flex-col items-center justify-center min-h-screen bg-gray-900 text-gray-100 antialiased overflow-hidden">
      {/* Banner de Imagens */}
      {bannerImages.map((src, index) => (
        <img
          key={src}
          src={src}
          alt={`Banner Image ${index + 1}`}
          className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 ease-in-out ${
            index === currentImageIndex ? 'opacity-100' : 'opacity-0'
          }`}
        />
      ))}
      
      {/* Overlay para escurecer um pouco o fundo e melhorar contraste */}
      <div className="absolute inset-0 bg-black/50 z-0"></div>

      {/* Conteúdo Central */}
      <div className="relative z-10 flex flex-col items-center justify-center text-center p-8 max-w-3xl bg-gray-900/70 backdrop-blur-sm rounded-xl shadow-2xl">
        <div className="mb-6">
          <LayersIcon className="w-20 h-20 mx-auto text-indigo-400" />
        </div>
        <h1 className="text-4xl sm:text-5xl font-bold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-indigo-300 to-purple-400">
          Bem-vindo ao Criador de Design Móvel
        </h1>
        <p className="text-lg sm:text-xl text-gray-200 mb-8 leading-relaxed">
          Transforme suas ideias em realidade. Crie, edite e visualize designs de interface de usuário para dispositivos móveis de forma intuitiva e eficiente.
        </p>
      </div>

      {/* Container para Elementos Inferiores Fixos */}
      <div className="fixed inset-x-0 bottom-0 z-20 flex justify-center pb-6 pointer-events-none">
        {/* Barra de Navegação Inferior - Agora container principal para todos os botões inferiores */}
        <nav className="
          relative /* Contexto para o botão + absoluto */
          pointer-events-auto
          w-full max-w-xs sm:max-w-[22rem] /* Largura da barra */
          bg-gray-800/80 backdrop-blur-md shadow-2xl 
          rounded-full 
          px-2 py-3 /* Padding interno da barra */
          flex justify-around items-center
        ">
            
            <NavButton text="Projetos" Icon={ProjectsIcon} onClick={() => console.log("Projetos clicado")} />
            <NavButton text="Config." Icon={SettingsIcon} onClick={() => console.log("Configurações clicado")} />
            <NavButton text="Conta" Icon={UserIcon} onClick={() => console.log("Conta clicado")} />

            {/* Botão Central "Criar Novo Projeto" - Posicionado absolutamente */}
            <div className="absolute left-1/2 top-0 transform -translate-x-1/2 -translate-y-8 z-10">
                 {/* -translate-y-8 (32px) move para cima. Com p-4 e ícone h-8 (total 64px), metade (32px) fica acima, metade sobrepõe. */}
                <button
                    onClick={onStartCreating}
                    className="
                       bg-gradient-to-br from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700
                       text-white p-4 rounded-full shadow-xl 
                       transition-all duration-300 ease-in-out
                       transform hover:scale-110 focus:outline-none focus:ring-4
                       focus:ring-indigo-400 focus:ring-opacity-60"
                    aria-label="Criar novo projeto"
                    title="Criar Novo Projeto"
                >
                    <PlusIcon className="w-8 h-8" />
                </button>
            </div>
        </nav>
      </div>
    </div>
  );
};
